package com.dh.pagos.model;

public enum Tipo {

    DEBITO,
    CREDITO
}
