package com.dh.projetointegrador.base.inicioprojetointegrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InicioprojetointegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
