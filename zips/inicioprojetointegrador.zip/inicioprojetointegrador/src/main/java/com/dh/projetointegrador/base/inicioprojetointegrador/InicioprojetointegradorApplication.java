package com.dh.projetointegrador.base.inicioprojetointegrador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InicioprojetointegradorApplication {

	public static void main(String[] args) {
		SpringApplication.run(InicioprojetointegradorApplication.class, args);
	}

}
