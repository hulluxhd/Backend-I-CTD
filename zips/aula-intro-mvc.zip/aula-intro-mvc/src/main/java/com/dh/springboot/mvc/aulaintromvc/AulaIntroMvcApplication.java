package com.dh.springboot.mvc.aulaintromvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaIntroMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaIntroMvcApplication.class, args);
	}

}
