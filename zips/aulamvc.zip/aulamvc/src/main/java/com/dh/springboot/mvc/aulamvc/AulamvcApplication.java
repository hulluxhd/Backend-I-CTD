package com.dh.springboot.mvc.aulamvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulamvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulamvcApplication.class, args);
	}

}
