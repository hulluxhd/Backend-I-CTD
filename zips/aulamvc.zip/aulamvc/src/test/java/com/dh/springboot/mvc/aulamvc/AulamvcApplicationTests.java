package com.dh.springboot.mvc.aulamvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulamvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
